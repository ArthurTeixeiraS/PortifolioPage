<h1>Landing Page</h1>
Projeto feito com os conhecimentos adiquiridos em HTML e CSS no Curso de JavaScript e <br>
TypeScript que estou cursando.
